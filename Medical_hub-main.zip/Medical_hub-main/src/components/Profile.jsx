import React from 'react'

function Profile() {
  return (
    <div>
      Helloooooo
    </div>
  )
}

export default Profile
