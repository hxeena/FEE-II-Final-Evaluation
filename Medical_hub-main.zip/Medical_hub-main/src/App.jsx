import "./App.css";
import Layout from "./layout/Layout.jsx";
import { createBrowserRouter,Form,RouterProvider } from 'react-router-dom';

function App() {
  return (
    <>
    <Layout/>
    </>
  );
}

export default App;

